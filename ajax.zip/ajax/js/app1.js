/*
тойргийн диаметр, тойрог, талбайг олох С програм бич

talbai = 2p*r2

*/

// const square = (r)=>{
//    const aa = r*r
//    return aa;
// }
// const diametr = (d)=>{
//     return radius= d/2 
// }
// const diametr1 = diametr(5)
// console.log(diametr1)
// const p = 3.14;
// const square1 = 2 * p * square(diametr(10));
// console.log(`${square1} talbai ni`)


/*

Функц ашиглан хоёр тооны 
хоорондох хамгийн их ба хамгийн бага тоог

*/

// const num1 = prompt("ehni toog oruulna uu");
// const num2 = prompt("2 dahi toog oruulna uu");
// const minMax = (min,max)=>{
//     if(max > min){
//         return max;
//     } else{
//         return min;
//     }
// }
// console.log(minMax(num1,num2))

/*

функцийг ашиглан тоо тэгш 
эсвэл сондгой эсэхийг шалгана уу.

*/
// let data ="";
// let data1 ="";
// const num =[1,2,3,4,5,6,7,8,9,10]

// const numCon = (arr)=>{
//     for(i=0; i<arr.length; i++){
//         if(arr[i] % 2 == 0){
//             data += arr[i]
//         }else{
//              data1 += arr[i]
//         }
//     }
//     console.log(data);
//     console.log(data1);
// }

// console.log(numCon(num))


const numAdd = (x)=>{
    for(i=0; i<x.length; i++){
        // let add=0;
       
        // add +=i
    }
    console.log(i)
 
}
console.log(numAdd(5))