
const ajaxFuc = (arr,con)=>{
    let html = document.querySelector(con);
    for(i=0; i < arr.length; i++){
        let data1 =`
        <div class="content">
        <div class="content-img">
            <img src="${arr[i].avatar_url}" alt="" style="width: 100%;">
        </div>
          <div>
               <h5 class="name" >
               ${arr[i].login.toUpperCase()}
               </h5>
               <div>
                  <button id="btn"><a href=" ${arr[i].html_url}">Github profile</a></button>
               </div>
            </div>
        </div>
        `
        html.innerHTML += data1;
    }
}


const xhtCon = new XMLHttpRequest();
xhtCon.onreadystatechange = function(){
    const data = JSON.parse( this.responseText);
    ajaxFuc(data, "#con")
};

xhtCon.open('GET', 'https://api.github.com/users', true);
xhtCon.send();
